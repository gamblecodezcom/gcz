"""
Main FastAPI application.

Wires together database, models, schemas, and CRUD into a REST API.
Includes user registration/login (JWT), wallet ops, raffles, newsletter,
site reports, health checks, and admin-only docs + admin-only raffle actions.
"""

import os
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import (
    Depends,
    FastAPI,
    HTTPException,
    Request,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from . import crud, models, schemas
from .database import engine, get_db

# -------------------------------------------------------------------
# DB bootstrap
# -------------------------------------------------------------------
models.Base.metadata.create_all(bind=engine)

# -------------------------------------------------------------------
# OpenAPI metadata
# -------------------------------------------------------------------
tags_metadata = [
    {"name": "health", "description": "Service & database health checks"},
    {"name": "auth", "description": "Registration, login, JWT tokens"},
    {"name": "users", "description": "User account endpoints"},
    {"name": "wallet", "description": "Wallet & balance operations"},
    {"name": "raffles", "description": "Raffle endpoints"},
    {"name": "admin", "description": "Admin-only operations"},
    {"name": "newsletter", "description": "Newsletter subscriptions"},
    {"name": "reports", "description": "Site reports & feedback"},
]

# -------------------------------------------------------------------
# FastAPI app (docs disabled; admin-only below)
# -------------------------------------------------------------------
app = FastAPI(
    title="GambleCodez API",
    version="1.0.0",
    description="GambleCodez backend API",
    openapi_tags=tags_metadata,
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
)

# -------------------------------------------------------------------
# CORS
# -------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------------------------------------------
# Auth config
# -------------------------------------------------------------------
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/users/login")

SECRET_KEY = os.getenv("SECRET_KEY", "super-secret-key")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

# -------------------------------------------------------------------
# Auth helpers
# -------------------------------------------------------------------
class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: Optional[str] = None


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    payload = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    payload.update({"exp": expire})
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> models.User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if not username:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user = crud.get_user_by_username(db, username)
    if not user:
        raise credentials_exception

    return user


def require_admin(user: models.User = Depends(get_current_user)) -> models.User:
    if getattr(user, "is_admin", False):
        return user

    admin_username = os.getenv("ADMIN_USERNAME")
    if admin_username and user.username == admin_username:
        return user

    raise HTTPException(status_code=403, detail="Admin access required")

# -------------------------------------------------------------------
# Admin-only OpenAPI
# -------------------------------------------------------------------
@app.get("/api/docs", include_in_schema=False)
def admin_docs(_: models.User = Depends(require_admin)):
    return get_swagger_ui_html(
        openapi_url="/api/openapi.json",
        title="GambleCodez API (Admin)",
    )


@app.get("/api/openapi.json", include_in_schema=False)
def admin_openapi(_: models.User = Depends(require_admin)):
    return get_openapi(
        title="GambleCodez API",
        version="1.0.0",
        routes=app.routes,
    )

# -------------------------------------------------------------------
# Health
# -------------------------------------------------------------------
@app.get("/api/health", tags=["health"])
def health(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return {"status": "ok", "db": "ok"}
    except Exception:
        raise HTTPException(status_code=503, detail="db_unhealthy")

# -------------------------------------------------------------------
# Auth / Users
# -------------------------------------------------------------------
@app.post("/api/users/register", response_model=schemas.UserOut, tags=["auth"])
def register_user(user_in: schemas.UserCreate, db: Session = Depends(get_db)):
    if crud.get_user_by_username(db, user_in.username):
        raise HTTPException(status_code=400, detail="Username already registered")
    if crud.get_user_by_email(db, user_in.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db, user_in)


@app.post("/api/users/login", response_model=Token, tags=["auth"])
def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    user = crud.authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect username or password")

    token = create_access_token({"sub": user.username})
    return {"access_token": token, "token_type": "bearer"}


@app.get("/api/users/me", response_model=schemas.UserOut, tags=["users"])
def read_users_me(current_user: models.User = Depends(get_current_user)):
    return current_user

# -------------------------------------------------------------------
# Wallet
# -------------------------------------------------------------------
class WalletAction(BaseModel):
    amount: float = Field(..., gt=0)


@app.get("/api/wallet", response_model=schemas.WalletOut, tags=["wallet"])
def get_wallet(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    wallet = crud.get_wallet(db, current_user.id)
    return wallet or crud.credit_wallet(db, current_user.id, 0.0)


@app.post("/api/wallet/deposit", response_model=schemas.WalletOut, tags=["wallet"])
def deposit(
    data: WalletAction,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return crud.credit_wallet(db, current_user.id, data.amount)


@app.post("/api/wallet/withdraw", response_model=schemas.WalletOut, tags=["wallet"])
def withdraw(
    data: WalletAction,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    wallet = crud.debit_wallet(db, current_user.id, data.amount)
    if not wallet:
        raise HTTPException(status_code=400, detail="Insufficient balance")
    return wallet

# -------------------------------------------------------------------
# Raffles
# -------------------------------------------------------------------
@app.get("/api/raffles", response_model=List[schemas.RaffleOut], tags=["raffles"])
def list_raffles(db: Session = Depends(get_db)):
    return crud.list_active_raffles(db)


@app.post("/api/raffles", response_model=schemas.RaffleOut, tags=["admin"])
def create_raffle(
    raffle_in: schemas.RaffleCreate,
    _: models.User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    return crud.create_raffle(db, raffle_in)


@app.put("/api/raffles/{raffle_id}", response_model=schemas.RaffleOut, tags=["admin"])
def update_raffle(
    raffle_id: int,
    update_in: schemas.AdminRaffleUpdate,
    _: models.User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    raffle = crud.update_raffle(db, raffle_id, update_in)
    if not raffle:
        raise HTTPException(status_code=404, detail="Raffle not found")
    return raffle


@app.post("/api/raffles/{raffle_id}/stop", response_model=schemas.RaffleOut, tags=["admin"])
def stop_raffle(
    raffle_id: int,
    _: models.User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    raffle = crud.stop_raffle(db, raffle_id)
    if not raffle:
        raise HTTPException(status_code=404, detail="Raffle not found")
    return raffle


@app.post(
    "/api/raffles/{raffle_id}/winners",
    response_model=List[schemas.RaffleWinnerOut],
    tags=["admin"],
)
def assign_winners(
    raffle_id: int,
    assignment: schemas.RaffleWinnersAssign,
    _: models.User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    return crud.assign_raffle_winners(
        db,
        raffle_id,
        assignment.num_winners,
        assignment.claim_urls,
    )


@app.get(
    "/api/raffles/{raffle_id}/winners",
    response_model=List[schemas.RaffleWinnerOut],
    tags=["raffles"],
)
def list_winners(raffle_id: int, db: Session = Depends(get_db)):
    raffle = crud.get_raffle(db, raffle_id)
    if not raffle:
        raise HTTPException(status_code=404, detail="Raffle not found")
    return raffle.winners

# -------------------------------------------------------------------
# Raffle entries
# -------------------------------------------------------------------
@app.post("/api/raffle_entries", response_model=schemas.RaffleEntryOut, tags=["raffles"])
def enter_raffle(
    entry_in: schemas.RaffleEntryCreate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    entry = crud.enter_raffle(
        db,
        current_user.id,
        entry_in.raffle_id,
        entry_in.secret_password,
    )
    if not entry:
        raise HTTPException(status_code=400, detail="Unable to join raffle")
    return entry

# -------------------------------------------------------------------
# Newsletter
# -------------------------------------------------------------------
@app.post("/api/newsletter", response_model=schemas.NewsletterSubscriptionOut, tags=["newsletter"])
def subscribe_newsletter(subscription_in: schemas.NewsletterSubscriptionCreate, db: Session = Depends(get_db)):
    existing = crud.get_newsletter_by_email(db, subscription_in.email)
    return existing or crud.create_newsletter_subscription(db, subscription_in)

# -------------------------------------------------------------------
# Site reports
# -------------------------------------------------------------------
@app.post("/api/site_reports", response_model=schemas.SiteReportOut, tags=["reports"])
def report_site(
    report_in: schemas.SiteReportCreate,
    request: Request,
    db: Session = Depends(get_db),
):
    user_id: Optional[int] = None
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        try:
            payload = jwt.decode(auth.split(" ", 1)[1], SECRET_KEY, algorithms=[ALGORITHM])
            username = payload.get("sub")
            if username:
                user = crud.get_user_by_username(db, username)
                if user:
                    user_id = user.id
        except JWTError:
            pass

    payload = report_in.model_copy(update={"user_id": user_id})
    return crud.create_site_report(db, payload)

# -------------------------------------------------------------------
# Daily check-in
# -------------------------------------------------------------------
@app.post("/api/users/checkin", tags=["users"])
def daily_checkin(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not crud.check_in_user(db, current_user.id):
        raise HTTPException(status_code=400, detail="Already checked in today")
    return {"message": "Check-in successful"}