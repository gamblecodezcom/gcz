"""
SQLAlchemy ORM models.

These models are the single source of truth for the database schema.
They are fully aligned with schemas.py, crud.py, and app.py.
"""

from datetime import datetime
from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    ForeignKey,
    Boolean,
    Float,
    UniqueConstraint,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

# ------------------------------------------------------------------
# Users
# ------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(32), unique=True, index=True, nullable=False)
    email = Column(String(256), unique=True, index=True, nullable=False)
    hashed_password = Column(String(256), nullable=False)

    is_admin = Column(Boolean, default=False)

    last_checkin_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    wallet = relationship("Wallet", back_populates="user", uselist=False)
    raffle_entries = relationship("RaffleEntry", back_populates="user", cascade="all, delete-orphan")
    raffle_wins = relationship("RaffleWinner", back_populates="user", cascade="all, delete-orphan")
    site_reports = relationship("SiteReport", back_populates="user", cascade="all, delete-orphan")


# ------------------------------------------------------------------
# Wallets
# ------------------------------------------------------------------
class Wallet(Base):
    __tablename__ = "wallets"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    balance = Column(Float, default=0.0)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="wallet")


# ------------------------------------------------------------------
# Raffles
# ------------------------------------------------------------------
class Raffle(Base):
    __tablename__ = "raffles"

    id = Column(Integer, primary_key=True)
    title = Column(String(80), nullable=False)
    description = Column(String(2000), nullable=True)
    max_entries = Column(Integer, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    entries = relationship("RaffleEntry", back_populates="raffle", cascade="all, delete-orphan")
    winners = relationship("RaffleWinner", back_populates="raffle", cascade="all, delete-orphan")


# ------------------------------------------------------------------
# Raffle Entries
# ------------------------------------------------------------------
class RaffleEntry(Base):
    __tablename__ = "raffle_entries"
    __table_args__ = (
        UniqueConstraint("raffle_id", "user_id", name="uq_raffle_user"),
    )

    id = Column(Integer, primary_key=True)
    raffle_id = Column(Integer, ForeignKey("raffles.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    raffle = relationship("Raffle", back_populates="entries")
    user = relationship("User", back_populates="raffle_entries")


# ------------------------------------------------------------------
# Raffle Winners
# ------------------------------------------------------------------
class RaffleWinner(Base):
    __tablename__ = "raffle_winners"

    id = Column(Integer, primary_key=True)
    raffle_id = Column(Integer, ForeignKey("raffles.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    claim_url = Column(String(500), nullable=False)
    claimed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    raffle = relationship("Raffle", back_populates="winners")
    user = relationship("User", back_populates="raffle_wins")


# ------------------------------------------------------------------
# Newsletter
# ------------------------------------------------------------------
class NewsletterSubscription(Base):
    __tablename__ = "newsletter_subscriptions"

    id = Column(Integer, primary_key=True)
    email = Column(String(256), unique=True, index=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# ------------------------------------------------------------------
# Site Reports
# ------------------------------------------------------------------
class SiteReport(Base):
    __tablename__ = "site_reports"

    id = Column(Integer, primary_key=True)
    message = Column(String(5000), nullable=False)
    email = Column(String(256), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="site_reports")
