from __future__ import annotations

from datetime import datetime
from typing import Optional, List

from pydantic import (
    BaseModel,
    EmailStr,
    ConfigDict,
    Field,
    HttpUrl,
)

# =====================
# BASE CONFIG (STRICT)
# =====================

STRICT_CONFIG = ConfigDict(
    from_attributes=True,
    extra="forbid",
    str_strip_whitespace=True,
    validate_assignment=True,
)

# =====================
# USER SCHEMAS
# =====================

USERNAME_RE = r"^[a-zA-Z0-9_]{3,32}$"

class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=32, pattern=USERNAME_RE)
    email: EmailStr

    model_config = STRICT_CONFIG


class UserCreate(UserBase):
    password: str = Field(..., min_length=8, max_length=128)


class UserOut(UserBase):
    id: int
    created_at: Optional[datetime] = None


# =====================
# AUTH
# =====================

class Token(BaseModel):
    access_token: str
    token_type: str


# =====================
# WALLET
# =====================

class WalletOut(BaseModel):
    id: int
    balance: float = Field(..., ge=0)
    updated_at: Optional[datetime] = None

    model_config = STRICT_CONFIG


# =====================
# RAFFLES
# =====================

class RaffleBase(BaseModel):
    title: str = Field(..., min_length=3, max_length=80)
    description: Optional[str] = Field(None, max_length=2000)
    max_entries: int = Field(..., ge=1, le=1_000_000)
    is_active: bool = True

    model_config = STRICT_CONFIG


class RaffleCreate(RaffleBase):
    pass


class RaffleOut(RaffleBase):
    id: int
    created_at: Optional[datetime] = None


class RaffleUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=3, max_length=80)
    description: Optional[str] = Field(None, max_length=2000)
    max_entries: Optional[int] = Field(None, ge=1, le=1_000_000)
    is_active: Optional[bool] = None

    model_config = STRICT_CONFIG


class RaffleWinnersAssign(BaseModel):
    num_winners: int = Field(..., gt=0, le=500)
    claim_urls: List[HttpUrl] = Field(..., min_length=1, max_length=500)

    model_config = STRICT_CONFIG


# =====================
# RAFFLE ENTRIES
# =====================

class RaffleEntryCreate(BaseModel):
    raffle_id: int
    secret_password: str = Field(..., min_length=1, max_length=128)

    model_config = STRICT_CONFIG


class RaffleEntryOut(BaseModel):
    id: int
    raffle_id: int
    user_id: int
    created_at: Optional[datetime] = None

    model_config = STRICT_CONFIG


# =====================
# RAFFLE WINNERS
# =====================

class RaffleWinnerOut(BaseModel):
    id: int
    raffle_id: int
    user_id: int
    claim_url: HttpUrl
    claimed: bool

    model_config = STRICT_CONFIG


# =====================
# NEWSLETTER
# =====================

class NewsletterSubscriptionCreate(BaseModel):
    email: EmailStr

    model_config = STRICT_CONFIG


class NewsletterSubscriptionOut(BaseModel):
    id: int
    email: EmailStr
    created_at: Optional[datetime] = None

    model_config = STRICT_CONFIG


# =====================
# SITE REPORTS
# =====================

class SiteReportCreate(BaseModel):
    message: str = Field(..., min_length=3, max_length=5000)
    email: Optional[EmailStr] = None
    user_id: Optional[int] = None

    model_config = STRICT_CONFIG


class SiteReportOut(BaseModel):
    id: int
    message: str
    email: Optional[EmailStr] = None
    user_id: Optional[int] = None
    created_at: Optional[datetime] = None

    model_config = STRICT_CONFIG


# ---------------------
# Compatibility aliases
# ---------------------

AdminRaffleUpdate = RaffleUpdate
