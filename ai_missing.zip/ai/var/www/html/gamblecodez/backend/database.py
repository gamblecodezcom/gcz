"""
Database engine and session management.

PostgreSQL-first, SQLite-compatible.
Safe for FastAPI dependency injection.
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./gcz.db")

ENGINE_KWARGS = {}

# SQLite needs this, Postgres does not
if DATABASE_URL.startswith("sqlite"):
    ENGINE_KWARGS["connect_args"] = {"check_same_thread": False}
else:
    # Production-safe pooling for Postgres
    ENGINE_KWARGS.update(
        pool_pre_ping=True,
        pool_size=5,
        max_overflow=10,
    )

engine = create_engine(
    DATABASE_URL,
    echo=False,
    future=True,
    **ENGINE_KWARGS,
)

SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
    future=True,
)


def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
