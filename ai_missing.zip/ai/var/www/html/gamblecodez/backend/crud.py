"""
CRUD (Create, Read, Update, Delete) utility functions.

Encapsulates all database interactions using SQLAlchemy ORM.
Called exclusively by FastAPI routes in app.py.
"""

from datetime import datetime
from typing import Optional, List
import random

from sqlalchemy.orm import Session
from passlib.context import CryptContext

from . import models, schemas

# ------------------------------------------------------------------
# Password hashing
# ------------------------------------------------------------------
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


# ------------------------------------------------------------------
# Users
# ------------------------------------------------------------------
def get_user_by_username(db: Session, username: str) -> Optional[models.User]:
    return db.query(models.User).filter(models.User.username == username).first()


def get_user_by_email(db: Session, email: str) -> Optional[models.User]:
    return db.query(models.User).filter(models.User.email == email).first()


def create_user(db: Session, user_in: schemas.UserCreate) -> models.User:
    hashed_password = get_password_hash(user_in.password)

    user = models.User(
        username=user_in.username,
        email=user_in.email,
        hashed_password=hashed_password,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    wallet = models.Wallet(user_id=user.id, balance=0.0)
    db.add(wallet)
    db.commit()

    return user


def authenticate_user(db: Session, username: str, password: str) -> Optional[models.User]:
    user = get_user_by_username(db, username)
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user


# ------------------------------------------------------------------
# Wallet
# ------------------------------------------------------------------
def get_wallet(db: Session, user_id: int) -> Optional[models.Wallet]:
    return db.query(models.Wallet).filter(models.Wallet.user_id == user_id).first()


def credit_wallet(db: Session, user_id: int, amount: float) -> models.Wallet:
    wallet = get_wallet(db, user_id)
    if not wallet:
        wallet = models.Wallet(user_id=user_id, balance=0.0)
        db.add(wallet)

    wallet.balance += float(amount)
    db.commit()
    db.refresh(wallet)
    return wallet


def debit_wallet(db: Session, user_id: int, amount: float) -> Optional[models.Wallet]:
    wallet = get_wallet(db, user_id)
    if not wallet or wallet.balance < amount:
        return None

    wallet.balance -= float(amount)
    db.commit()
    db.refresh(wallet)
    return wallet


# ------------------------------------------------------------------
# Raffles
# ------------------------------------------------------------------
def create_raffle(db: Session, raffle_in: schemas.RaffleCreate) -> models.Raffle:
    raffle = models.Raffle(
        title=raffle_in.title,
        description=raffle_in.description,
        max_entries=raffle_in.max_entries,
        is_active=True,
    )
    db.add(raffle)
    db.commit()
    db.refresh(raffle)
    return raffle


def list_active_raffles(db: Session) -> List[models.Raffle]:
    return (
        db.query(models.Raffle)
        .filter(models.Raffle.is_active.is_(True))
        .all()
    )


def get_raffle(db: Session, raffle_id: int) -> Optional[models.Raffle]:
    return db.query(models.Raffle).filter(models.Raffle.id == raffle_id).first()


def update_raffle(
    db: Session,
    raffle_id: int,
    update_data: schemas.RaffleUpdate,
) -> Optional[models.Raffle]:
    raffle = get_raffle(db, raffle_id)
    if not raffle:
        return None

    for field, value in update_data.model_dump(exclude_unset=True).items():
        setattr(raffle, field, value)

    db.commit()
    db.refresh(raffle)
    return raffle


def stop_raffle(db: Session, raffle_id: int) -> Optional[models.Raffle]:
    raffle = get_raffle(db, raffle_id)
    if not raffle:
        return None

    raffle.is_active = False
    db.commit()
    db.refresh(raffle)
    return raffle


# ------------------------------------------------------------------
# Raffle entries & winners
# ------------------------------------------------------------------
def enter_raffle(
    db: Session,
    user_id: int,
    raffle_id: int,
    secret_password: str,
) -> Optional[models.RaffleEntry]:
    raffle = get_raffle(db, raffle_id)
    if not raffle or not raffle.is_active:
        return None

    existing = (
        db.query(models.RaffleEntry)
        .filter(
            models.RaffleEntry.raffle_id == raffle_id,
            models.RaffleEntry.user_id == user_id,
        )
        .first()
    )
    if existing:
        return existing

    entry = models.RaffleEntry(
        raffle_id=raffle_id,
        user_id=user_id,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


def assign_raffle_winners(
    db: Session,
    raffle_id: int,
    num_winners: int,
    claim_urls: List[str],
) -> Optional[List[models.RaffleWinner]]:
    raffle = get_raffle(db, raffle_id)
    if not raffle or not raffle.is_active:
        return None

    entries = (
        db.query(models.RaffleEntry)
        .filter(models.RaffleEntry.raffle_id == raffle_id)
        .all()
    )
    if len(entries) < num_winners:
        return None

    if len(claim_urls) < num_winners:
        raise ValueError("Not enough claim URLs provided")

    winners = random.sample(entries, num_winners)
    winner_objs: List[models.RaffleWinner] = []

    for entry, url in zip(winners, claim_urls):
        winner = models.RaffleWinner(
            raffle_id=raffle_id,
            user_id=entry.user_id,
            claim_url=url,
            claimed=False,
        )
        db.add(winner)
        winner_objs.append(winner)

    raffle.is_active = False
    db.commit()

    for w in winner_objs:
        db.refresh(w)

    return winner_objs


# ------------------------------------------------------------------
# Newsletter
# ------------------------------------------------------------------
def get_newsletter_by_email(db: Session, email: str) -> Optional[models.NewsletterSubscription]:
    return (
        db.query(models.NewsletterSubscription)
        .filter(models.NewsletterSubscription.email == email)
        .first()
    )


def create_newsletter_subscription(
    db: Session,
    subscription_in: schemas.NewsletterSubscriptionCreate,
) -> models.NewsletterSubscription:
    sub = models.NewsletterSubscription(email=subscription_in.email)
    db.add(sub)
    db.commit()
    db.refresh(sub)
    return sub


# ------------------------------------------------------------------
# Site reports
# ------------------------------------------------------------------
def create_site_report(
    db: Session,
    report_in: schemas.SiteReportCreate,
) -> models.SiteReport:
    report = models.SiteReport(
        message=report_in.message,
        email=report_in.email,
        user_id=report_in.user_id,
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


# ------------------------------------------------------------------
# Daily check-in
# ------------------------------------------------------------------
def check_in_user(db: Session, user_id: int) -> bool:
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        return False

    now = datetime.utcnow()
    if user.last_checkin_at and user.last_checkin_at.date() == now.date():
        return False

    user.last_checkin_at = now
    wallet = get_wallet(db, user_id)
    if wallet:
        wallet.balance += 0.1

    db.commit()
    return True
