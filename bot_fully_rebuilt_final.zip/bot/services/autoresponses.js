/* Auto-responses for groups */
