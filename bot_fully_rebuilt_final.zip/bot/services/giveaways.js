/* Giveaway logic */
