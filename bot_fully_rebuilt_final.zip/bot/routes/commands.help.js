/* Help command logic */
