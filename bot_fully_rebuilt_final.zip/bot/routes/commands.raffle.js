/* Raffle commands logic */
