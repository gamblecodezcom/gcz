/* User commands logic */
