/* Telegram client setup */
