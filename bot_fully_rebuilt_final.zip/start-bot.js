// Telegram bot launcher for PM2
import { bot } from './bot/client.js';
bot.launch().then(() => console.log('🤖 GCZ Bot Started'));
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
