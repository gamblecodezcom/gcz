/* Raffle backend integration */
