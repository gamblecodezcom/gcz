import React from "react";

export default function App() {
  return (
    <div style={{ color: "white", padding: "40px", fontSize: "24px" }}>
      <h1>GambleCodez Frontend Loaded</h1>
      <p>If you see this, the React app is working.</p>
    </div>
  );
}
