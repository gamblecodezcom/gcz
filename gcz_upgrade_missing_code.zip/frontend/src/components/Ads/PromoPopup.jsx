import React from 'react';

export default function PromoPopup() {
  return null;
}
