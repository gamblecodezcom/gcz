// app.js - GambleCodez Admin Backend (Upgraded)

require('dotenv').config();

const express = require('express');
const path = require('path');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);
const Joi = require('joi');
const winston = require('winston');

const db = require('./db');              // mysql2/promise pool wrapper with query/queryOne
const SA = require('./sweepsAssistant'); // daily build/post/edit helpers
const notifyAdmins = require('./notifyAdmins');
const helpers = require('./helpers');    // escapeHtml, getRoles, etc.

const app = express();

// ---------- Logging ----------
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ level, message, timestamp }) => `${timestamp} [${level}] ${message}`)
  ),
  transports: [
    new winston.transports.Console()
  ]
});

// ---------- Security & Core Middleware ----------
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: false
}));

app.use(cors({
  origin: process.env.CORS_ORIGIN?.split(',').map(s => s.trim()) || ['*'],
  credentials: true
}));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ---------- Sessions (MySQL-backed) ----------
const sessionStore = new MySQLStore({
  expiration: 1000 * 60 * 60 * 24, // 1 day
  clearExpired: true,
  checkExpirationInterval: 1000 * 60 * 10, // 10 min
  endConnectionOnClose: false,
  createDatabaseTable: true,
}, db.pool);

app.use(session({
  key: process.env.SESSION_COOKIE_NAME || 'gcz.sid',
  secret: process.env.SESSION_SECRET || 'change_me',
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 24
  }
}));

// ---------- Rate Limiting ----------
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120
});

app.use('/api/', apiLimiter);

// ---------- Static Frontend ----------
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Helpers ----------
const ROLES = helpers.getRoles(process.env);

function requireAuth(req, res, next) {
  if (!req.session?.user) return res.status(401).json({ success: false, message: 'Unauthorized' });
  next();
}

function requireRole(minLevel) {
  return (req, res, next) => {
    const uid = req.session?.user?.telegram_user_id || req.session?.user?.id || 0;
    if (!helpers.hasRoleAtLeast(ROLES, uid, minLevel)) {
      return res.status(403).json({ success: false, message: 'Forbidden' });
    }
    next();
  };
}

// ---------- Schemas ----------
const loginSchema = Joi.object({
  username: Joi.string().min(3).max(190).required(),
  password: Joi.string().min(6).max(190).required()
});

const approveRejectSchema = Joi.object({
  id: Joi.number().integer().positive().required()
});

const scheduleSchema = Joi.object({
  time: Joi.string().pattern(/^d{1,2}:d{2}$/).required()
});

// ---------- API Routes ----------

// Health & Metrics
app.get('/api/health', async (req, res) => {
  try {
    await db.query('SELECT 1');
    return res.json({ status: 'ok', service: 'GambleCodez Admin', db: 'up', time: new Date().toISOString() });
  } catch (e) {
    return res.status(500).json({ status: 'degraded', service: 'GambleCodez Admin', db: 'down' });
  }
});

app.get('/api/metrics', requireAuth, requireRole(2), async (req, res) => {
  try {
    const [subs, posts] = await Promise.all([
      db.query('SELECT COUNT(*) AS c FROM sweeps_submissions'),
      db.query('SELECT COUNT(*) AS c FROM sweeps_posts')
    ]);
    res.json({
      submissions: subs[0]?.c || 0,
      posts: posts[0]?.c || 0
    });
  } catch (e) {
    logger.error(`metrics error: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

// Auth
app.post('/api/login', authLimiter, async (req, res) => {
  const { error, value } = loginSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.message });

  const { username, password } = value;
  if (username === process.env.ADMIN_USERNAME && password === process.env.ADMIN_PASSWORD) {
    // Minimal user in session; enhance by loading telegram_user link if desired
    req.session.user = { id: 1, username, role: 3 };
    return res.json({ success: true });
  }
  return res.status(401).json({ success: false, message: 'Invalid credentials' });
});

app.post('/api/logout', requireAuth, (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

// Admin flags (mute alerts)
app.get('/api/admin/flags', requireAuth, requireRole(2), async (req, res) => {
  try {
    const uid = req.session.user.id;
    const flags = await db.queryOne('SELECT * FROM admin_flags WHERE telegram_user_id = ?', [uid]);
    res.json({ success: true, flags: flags || { mute_alerts: 0 } });
  } catch (e) {
    logger.error(`flags get: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

app.post('/api/admin/flags', requireAuth, requireRole(2), async (req, res) => {
  try {
    const uid = req.session.user.id;
    const mute = req.body?.mute_alerts ? 1 : 0;
    await db.query(
      `INSERT INTO admin_flags (telegram_user_id, mute_alerts, created_at, updated_at)
       VALUES (?, ?, NOW(), NOW())
       ON DUPLICATE KEY UPDATE mute_alerts = VALUES(mute_alerts), updated_at = NOW()`,
      [uid, mute]
    );
    res.json({ success: true, mute_alerts: mute });
  } catch (e) {
    logger.error(`flags set: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

// Submissions review
app.get('/api/submissions/pending', requireAuth, requireRole(2), async (req, res) => {
  try {
    const rows = await db.query(
      `SELECT s.* FROM sweeps_submissions s
       WHERE s.status = 'pending'
       ORDER BY s.created_at DESC
       LIMIT 100`
    );
    res.json({ success: true, submissions: rows });
  } catch (e) {
    logger.error(`pending submissions: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

app.post('/api/submissions/approve', requireAuth, requireRole(2), async (req, res) => {
  const { error, value } = approveRejectSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.message });
  const { id } = value;

  try {
    const sub = await db.queryOne('SELECT * FROM sweeps_submissions WHERE id = ?', [id]);
    if (!sub) return res.status(404).json({ success: false, message: 'Not found' });
    if (sub.status !== 'pending') return res.status(409).json({ success: false, message: `Already ${sub.status}` });

    await SA.reviewSubmission(db, id, 'approved');
    // Append to daily post (if cached message exists)
    const urls = sub.urls.split(',').map(u => u.trim()).join(',');
    await SA.appendPromToDaily(
      { telegram: { editMessageText: async () => {}, sendMessage: async () => {} } }, // placeholder bot object not needed for DB write; real edits require bot process
      db,
      { site_name: sub.site_name, bonus: sub.bonus, urls }
    ).catch(() => { /* No-op if not cached in API context */ });

    // Notify admins asynchronously
    notifyAdmins(
      { telegram: { sendMessage: async () => {} } },
      db,
      ROLES,
      `✅ Submission #${id} approved from Admin panel`,
      req.session.user.id,
      'info',
      2
    ).catch(() => {});

    res.json({ success: true });
  } catch (e) {
    logger.error(`approve: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

app.post('/api/submissions/reject', requireAuth, requireRole(2), async (req, res) => {
  const { error, value } = approveRejectSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.message });
  const { id } = value;

  try {
    const sub = await db.queryOne('SELECT * FROM sweeps_submissions WHERE id = ?', [id]);
    if (!sub) return res.status(404).json({ success: false, message: 'Not found' });
    if (sub.status !== 'pending') return res.status(409).json({ success: false, message: `Already ${sub.status}` });

    await SA.reviewSubmission(db, id, 'rejected');

    notifyAdmins(
      { telegram: { sendMessage: async () => {} } },
      db,
      ROLES,
      `❌ Submission #${id} rejected from Admin panel`,
      req.session.user.id,
      'warning',
      2
    ).catch(() => {});

    res.json({ success: true });
  } catch (e) {
    logger.error(`reject: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

// Dailies management (server-side actions)
app.post('/api/dailies/build', requireAuth, requireRole(2), async (req, res) => {
  try {
    const html = await SA.buildDailySweepsPost(db, { limit: 100 });
    res.json({ success: true, html });
  } catch (e) {
    logger.error(`build dailies: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

// Optional: trigger post via API, if bot is accessible via IPC/RPC
// Here we only store a job request in DB to be picked by the bot process.
app.post('/api/dailies/request-post', requireAuth, requireRole(3), async (req, res) => {
  try {
    await db.query(
      `INSERT INTO admin_alerts (telegram_user_id, message, source, severity, created_at)
       VALUES (?, ?, ?, 'info', NOW())`,
      [req.session.user.id, 'REQUEST_POST_DAILIES', 0]
    );
    res.json({ success: true, queued: true });
  } catch (e) {
    logger.error(`request post: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

// Scheduling via admin API (the actual schedule runs inside the bot process)
// This stores the preferred time; the bot can read and reschedule accordingly.
app.post('/api/dailies/schedule', requireAuth, requireRole(3), async (req, res) => {
  const { error, value } = scheduleSchema.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.message });

  try {
    await db.query(
      `INSERT INTO settings (k, v, updated_at)
       VALUES ('dailies_time', ?, NOW())
       ON DUPLICATE KEY UPDATE v = VALUES(v), updated_at = NOW()`,
      [value.time]
    );
    res.json({ success: true, time: value.time });
  } catch (e) {
    logger.error(`schedule save: ${e.message}`);
    res.status(500).json({ success: false });
  }
});

// ---------- Fallback route ----------
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ---------- Boot ----------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  logger.info(`GambleCodez Admin running at http://localhost:${PORT}`);
});