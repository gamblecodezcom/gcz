// index.js - GambleCodez Admin Dashboard Server
require('dotenv').config();

const express = require('express');
const path = require('path');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);
const Joi = require('joi');
const winston = require('winston');

// Import shared modules from bot directory
const db = require('./bot/db');
const SA = require('./bot/sweepsAssistant');
const notifyAdmins = require('./bot/notifyAdmins');
const helpers = require('./bot/helpers');

const app = express();

// Logging
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ level, message, timestamp }) => 
      `${timestamp} [${level.toUpperCase()}] ${message}`
    )
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/admin.log' })
  ]
});

// Security middleware
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: false
}));

app.use(cors({
  origin: process.env.CORS_ORIGIN?.split(',').map(s => s.trim()) || ['*'],
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Session store
const sessionStore = new MySQLStore({
  expiration: 1000 * 60 * 60 * 24, // 24 hours
  clearExpired: true,
  checkExpirationInterval: 1000 * 60 * 10, // 10 minutes
  endConnectionOnClose: false,
  createDatabaseTable: true,
}, db.pool);

app.use(session({
  key: process.env.SESSION_COOKIE_NAME || 'gcz.sid',
  secret: process.env.SESSION_SECRET || 'change_this_secret_key',
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 24 // 24 hours
  }
}));

// Rate limiting
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10 // 10 attempts
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100 // 100 requests per minute
});

app.use('/api/', apiLimiter);

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Get roles
const ROLES = helpers.getRoles(process.env);

// Auth middleware
function requireAuth(req, res, next) {
  if (!req.session?.user) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }
  next();
}

function requireRole(minLevel) {
  return (req, res, next) => {
    const uid = req.session?.user?.telegram_user_id || req.session?.user?.id || 0;
    if (!helpers.hasRoleAtLeast(ROLES, uid, minLevel)) {
      return res.status(403).json({ success: false, message: 'Forbidden' });
    }
    next();
  };
}

// Validation schemas
const loginSchema = Joi.object({
  username: Joi.string().min(3).max(50).required(),
  password: Joi.string().min(6).max(100).required()
});

const submissionActionSchema = Joi.object({
  id: Joi.number().integer().positive().required(),
  action: Joi.string().valid('approve', 'reject').optional(),
  bonus: Joi.string().max(200).optional(),
  urls: Joi.string().max(1000).optional()
});

// API Routes

// Health check
app.get('/api/health', async (req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ 
      status: 'ok', 
      service: 'GambleCodez Admin Dashboard',
      db: 'connected',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error(`Health check failed: ${error.message}`);
    res.status(500).json({ 
      status: 'error', 
      service: 'GambleCodez Admin Dashboard',
      db: 'disconnected'
    });
  }
});

// Authentication
app.post('/api/login', authLimiter, async (req, res) => {
  try {
    const { error, value } = loginSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ success: false, message: error.message });
    }

    const { username, password } = value;
    
    // Simple auth check (enhance with bcrypt in production)
    if (username === process.env.ADMIN_USERNAME && password === process.env.ADMIN_PASSWORD) {
      req.session.user = { 
        id: 1, 
        username, 
        telegram_user_id: parseInt(process.env.ADMIN_TELEGRAM_ID) || 1,
        role: 3 
      };
      
      logger.info(`Admin login successful: ${username}`);
      return res.json({ success: true, user: { username, role: 3 } });
    }
    
    logger.warn(`Failed login attempt: ${username}`);
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  } catch (error) {
    logger.error(`Login error: ${error.message}`);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

app.post('/api/logout', requireAuth, (req, res) => {
  const username = req.session.user?.username;
  req.session.destroy(() => {
    logger.info(`Admin logout: ${username}`);
    res.json({ success: true });
  });
});

// Dashboard metrics
app.get('/api/metrics', requireAuth, requireRole(2), async (req, res) => {
  try {
    const [pending, approved, rejected, posts] = await Promise.all([
      db.query('SELECT COUNT(*) as count FROM sweeps_submissions WHERE status = "pending"'),
      db.query('SELECT COUNT(*) as count FROM sweeps_submissions WHERE status = "approved"'),
      db.query('SELECT COUNT(*) as count FROM sweeps_submissions WHERE status = "rejected"'),
      db.query('SELECT COUNT(*) as count FROM sweeps_posts WHERE DATE(created_at) = CURDATE()')
    ]);
    
    res.json({
      success: true,
      metrics: {
        pending_submissions: pending[0]?.count || 0,
        approved_submissions: approved[0]?.count || 0,
        rejected_submissions: rejected[0]?.count || 0,
        daily_posts: posts[0]?.count || 0
      }
    });
  } catch (error) {
    logger.error(`Metrics error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

// Submissions management
app.get('/api/submissions', requireAuth, requireRole(2), async (req, res) => {
  try {
    const status = req.query.status || 'pending';
    const limit = Math.min(parseInt(req.query.limit) || 50, 100);
    const offset = Math.max(parseInt(req.query.offset) || 0, 0);
    
    const submissions = await db.query(
      `SELECT s.*, ts.username as submitter_username
       FROM sweeps_submissions s
       LEFT JOIN telegram_sessions ts ON s.user_id = ts.telegram_user_id
       WHERE s.status = ?
       ORDER BY s.created_at DESC
       LIMIT ? OFFSET ?`,
      [status, limit, offset]
    );
    
    res.json({ success: true, submissions });
  } catch (error) {
    logger.error(`Submissions fetch error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

app.post('/api/submissions/action', requireAuth, requireRole(2), async (req, res) => {
  try {
    const { error, value } = submissionActionSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ success: false, message: error.message });
    }

    const { id, action, bonus, urls } = value;
    
    const submission = await db.queryOne(
      'SELECT * FROM sweeps_submissions WHERE id = ?',
      [id]
    );
    
    if (!submission) {
      return res.status(404).json({ success: false, message: 'Submission not found' });
    }
    
    if (submission.status !== 'pending') {
      return res.status(409).json({ 
        success: false, 
        message: `Submission already ${submission.status}` 
      });
    }
    
    if (action) {
      const status = action === 'approve' ? 'approved' : 'rejected';
      const newUrls = urls ? urls.split(',').map(u => u.trim()) : null;
      
      await SA.reviewSubmission(db, id, status, newUrls, bonus);
      
      if (action === 'approve') {
        // Add to daily post
        await SA.appendPromToDaily({ telegram: { editMessageText: async () => {} } }, db, {
          site_name: submission.site_name,
          bonus: bonus || submission.bonus,
          urls: urls || submission.urls
        }).catch(() => {}); // Ignore if no cached post
      }
      
      // Notify submitter
      try {
        const emoji = action === 'approve' ? '✅' : '❌';
        await notifyAdmins(
          { telegram: { sendMessage: async () => {} } },
          db,
          { admin2: [submission.user_id], admin3: [] },
          `${emoji} Your submission for ${submission.site_name} has been ${action}ed.`,
          req.session.user.id
        );
      } catch (e) {}
      
      logger.info(`Submission ${id} ${action}ed by admin ${req.session.user.username}`);
    }
    
    res.json({ success: true, action: action || 'updated' });
  } catch (error) {
    logger.error(`Submission action error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

// Daily sweeps management
app.get('/api/dailies/preview', requireAuth, requireRole(2), async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 100, 200);
    const html = await SA.buildDailySweepsPost(db, { limit });
    res.json({ success: true, html });
  } catch (error) {
    logger.error(`Dailies preview error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

app.post('/api/dailies/post', requireAuth, requireRole(3), async (req, res) => {
  try {
    const html = await SA.buildDailySweepsPost(db, { limit: 100 });
    
    // This would need actual bot instance - for now just log the intent
    logger.info(`Daily post requested by admin ${req.session.user.username}`);
    
    // Store request in database for bot to pick up
    await db.query(
      `INSERT INTO admin_alerts (telegram_user_id, message, source, severity, created_at)
       VALUES (?, 'REQUEST_POST_DAILIES', ?, 'info', NOW())`,
      [req.session.user.telegram_user_id, req.session.user.id]
    );
    
    res.json({ success: true, queued: true });
  } catch (error) {
    logger.error(`Daily post error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

// Admin flags
app.get('/api/admin/flags', requireAuth, requireRole(1), async (req, res) => {
  try {
    const uid = req.session.user.telegram_user_id;
    const flags = await db.queryOne(
      'SELECT * FROM admin_flags WHERE telegram_user_id = ?',
      [uid]
    );
    
    res.json({ 
      success: true, 
      flags: flags || { mute_alerts: 0, admin_mode: 0 } 
    });
  } catch (error) {
    logger.error(`Admin flags get error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

app.post('/api/admin/flags', requireAuth, requireRole(1), async (req, res) => {
  try {
    const uid = req.session.user.telegram_user_id;
    const { mute_alerts, admin_mode } = req.body;
    
    await db.query(
      `INSERT INTO admin_flags (telegram_user_id, is_admin, mute_alerts, admin_mode, created_at, updated_at)
       VALUES (?, 1, ?, ?, NOW(), NOW())
       ON DUPLICATE KEY UPDATE 
         mute_alerts = VALUES(mute_alerts), 
         admin_mode = VALUES(admin_mode), 
         updated_at = NOW()`,
      [uid, mute_alerts ? 1 : 0, admin_mode ? 1 : 0]
    );
    
    res.json({ success: true });
  } catch (error) {
    logger.error(`Admin flags set error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

// Settings management
app.get('/api/settings', requireAuth, requireRole(3), async (req, res) => {
  try {
    const settings = await db.query('SELECT k, v FROM settings');
    const settingsObj = {};
    settings.forEach(s => {
      try {
        settingsObj[s.k] = JSON.parse(s.v);
      } catch (e) {
        settingsObj[s.k] = s.v;
      }
    });
    
    res.json({ success: true, settings: settingsObj });
  } catch (error) {
    logger.error(`Settings get error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

app.post('/api/settings', requireAuth, requireRole(3), async (req, res) => {
  try {
    const { key, value } = req.body;
    
    if (!key) {
      return res.status(400).json({ success: false, message: 'Key required' });
    }
    
    await db.query(
      'INSERT INTO settings (k, v, updated_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE v = VALUES(v), updated_at = NOW()',
      [key, JSON.stringify(value)]
    );
    
    logger.info(`Setting updated: ${key} by ${req.session.user.username}`);
    res.json({ success: true });
  } catch (error) {
    logger.error(`Settings set error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

// Telegram integration status
app.get('/api/bot/status', requireAuth, requireRole(2), async (req, res) => {
  try {
    // Check if bot process is responsive by checking recent activity
    const recentActivity = await db.queryOne(
      'SELECT COUNT(*) as count FROM command_logs WHERE executed_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)'
    );
    
    const lastPost = await db.queryOne(
      'SELECT created_at FROM sweeps_posts ORDER BY created_at DESC LIMIT 1'
    );
    
    res.json({
      success: true,
      bot_status: {
        active: (recentActivity?.count || 0) > 0,
        last_activity: recentActivity?.count || 0,
        last_post: lastPost?.created_at || null
      }
    });
  } catch (error) {
    logger.error(`Bot status error: ${error.message}`);
    res.status(500).json({ success: false });
  }
});

// SPA fallback route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handler
app.use((error, req, res, next) => {
  logger.error(`Unhandled error: ${error.message}`);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

// Start server
const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    // Test database connection
    const dbConnected = await db.testConnection();
    if (!dbConnected) {
      throw new Error('Database connection failed');
    }
    
    app.listen(PORT, () => {
      logger.info(`✅ GambleCodez Admin Dashboard running on port ${PORT}`);
      logger.info(`   Environment: ${process.env.NODE_ENV || 'development'}`);
      logger.info(`   Admin Levels: L3=${ROLES.admin3.join(',')}, L2=${ROLES.admin2.join(',')}`);
      console.log(`
🎰 GambleCodez Admin Dashboard`);
      console.log(`📊 Dashboard: http://localhost:${PORT}`);
      console.log(`🔗 API Health: http://localhost:${PORT}/api/health`);
    });
  } catch (error) {
    logger.error(`❌ Server startup failed: ${error.message}`);
    process.exit(1);
  }
}

// Graceful shutdown
process.once('SIGINT', async () => {
  logger.info('🛑 Shutting down admin dashboard...');
  await db.closePool();
  process.exit(0);
});

process.once('SIGTERM', async () => {
  logger.info('🛑 Shutting down admin dashboard...');
  await db.closePool();
  process.exit(0);
});

startServer();