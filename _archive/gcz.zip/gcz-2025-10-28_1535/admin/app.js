// app.js - GambleCodez Admin Portal

const express = require('express');
const path = require('path');
require('dotenv').config();   // load .env

const app = express();

// In-memory state (DB later)
const state = {
  isAuthenticated: false,
  affiliates: [ /* ... same as before ... */ ],
  campaigns: [ /* ... same as before ... */ ]
};

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend
app.use(express.static(path.join(__dirname, 'public')));

// --- API ROUTES ---

// Login
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (
    username === process.env.ADMIN_USERNAME &&
    password === process.env.ADMIN_PASSWORD
  ) {
    state.isAuthenticated = true;
    res.json({ success: true });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
});

// Logout
app.post('/api/logout', (req, res) => {
  state.isAuthenticated = false;
  res.json({ success: true });
});

// Affiliates
app.get('/api/affiliates', (req, res) => {
  if (!state.isAuthenticated) return res.status(403).json({ error: 'Not authenticated' });
  res.json(state.affiliates);
});

// Campaigns
app.get('/api/campaigns', (req, res) => {
  if (!state.isAuthenticated) return res.status(403).json({ error: 'Not authenticated' });
  res.json(state.campaigns);
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'GambleCodez Admin' });
});

// Default route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ GambleCodez Admin running at http://localhost:${PORT}`);
});
