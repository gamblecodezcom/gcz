// scripts/migrate.js - Database Migration Runner

const fs = require('fs');
const path = require('path');
const db = require('../api/db');

// ANSI color codes for terminal output
const colors = {
  reset: '\u001B[0m',
  bright: '\u001B[1m',
  green: '\u001B[32m',
  red: '\u001B[31m',
  yellow: '\u001B[33m',
  blue: '\u001B[34m',
  cyan: '\u001B[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

// Create migrations tracking table
async function ensureMigrationsTable() {
  const sql = `
    CREATE TABLE IF NOT EXISTS migrations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      filename VARCHAR(255) NOT NULL UNIQUE,
      executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_filename (filename)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `;
  
  try {
    await db.query(sql);
    log('✓ Migrations table ready', 'green');
  } catch (error) {
    log(`✗ Failed to create migrations table: ${error.message}`, 'red');
    throw error;
  }
}

// Check if migration has been executed
async function hasBeenExecuted(filename) {
  const result = await db.queryOne(
    'SELECT id FROM migrations WHERE filename = ?',
    [filename]
  );
  return !!result;
}

// Mark migration as executed
async function markAsExecuted(filename) {
  await db.query(
    'INSERT INTO migrations (filename) VALUES (?)',
    [filename]
  );
}

// Execute a single SQL file
async function executeMigrationFile(filePath, filename) {
  log(`
→ Executing: ${filename}`, 'cyan');
  
  const sql = fs.readFileSync(filePath, 'utf8');
  
  // Split by semicolon and execute each statement
  const statements = sql
    .split(';')
    .map(s => s.trim())
    .filter(s => s.length > 0 && !s.startsWith('--') && !s.startsWith('/*'));
  
  let successCount = 0;
  let skipCount = 0;
  
  for (let i = 0; i < statements.length; i++) {
    const statement = statements[i];
    
    try {
      await db.query(statement);
      successCount++;
    } catch (error) {
      // Ignore "already exists" errors
      if (
        error.message.includes('already exists') ||
        error.message.includes('Duplicate') ||
        error.code === 'ER_TABLE_EXISTS_ERROR' ||
        error.code === 'ER_DUP_FIELDNAME'
      ) {
        skipCount++;
      } else {
        log(`  ✗ Statement ${i + 1} failed: ${error.message}`, 'red');
        log(`  SQL: ${statement.substring(0, 100)}...`, 'yellow');
        throw error;
      }
    }
  }
  
  log(`  ✓ Executed ${successCount} statements (${skipCount} skipped)`, 'green');
}

// Main migration runner
async function runMigrations() {
  log('═══════════════════════════════════════', 'bright');
  log('  GambleCodez Database Migration Tool  ', 'bright');
  log('═══════════════════════════════════════
', 'bright');
  
  try {
    // Test database connection
    const connected = await db.testConnection();
    if (!connected) {
      throw new Error('Database connection failed');
    }
    
    // Ensure migrations tracking table exists
    await ensureMigrationsTable();
    
    // Get all SQL files from sql directory
    const sqlDir = path.join(__dirname, '../sql');
    
    if (!fs.existsSync(sqlDir)) {
      log(`Creating sql directory: ${sqlDir}`, 'yellow');
      fs.mkdirSync(sqlDir, { recursive: true });
    }
    
    const files = fs.readdirSync(sqlDir)
      .filter(f => f.endsWith('.sql'))
      .sort();
    
    if (files.length === 0) {
      log('⚠ No migration files found in /sql directory', 'yellow');
      await db.close();
      process.exit(0);
    }
    
    log(`Found ${files.length} migration file(s)
`, 'blue');
    
    let executed = 0;
    let skipped = 0;
    
    for (const file of files) {
      const filePath = path.join(sqlDir, file);
      
      // Check if already executed
      if (await hasBeenExecuted(file)) {
        log(`⊘ Skipping ${file} (already executed)`, 'yellow');
        skipped++;
        continue;
      }
      
      // Execute migration
      await executeMigrationFile(filePath, file);
      
      // Mark as executed
      await markAsExecuted(file);
      executed++;
    }
    
    log('
═══════════════════════════════════════', 'bright');
    log(`✓ Migration complete!`, 'green');
    log(`  Executed: ${executed}`, 'green');
    log(`  Skipped: ${skipped}`, 'yellow');
    log('═══════════════════════════════════════
', 'bright');
    
    await db.close();
    process.exit(0);
    
  } catch (error) {
    log('
═══════════════════════════════════════', 'bright');
    log(`✗ Migration failed: ${error.message}`, 'red');
    log('═══════════════════════════════════════
', 'bright');
    
    await db.close();
    process.exit(1);
  }
}

// Run if executed directly
if (require.main === module) {
  runMigrations();
}

module.exports = { runMigrations };
