<?php
// Admin Environment Configuration
$_ENV['ADMIN_ID'] = 'ADMIN_12345';
$_ENV['DEPLOY_PIN'] = 'PIN12345';
$_ENV['ADMIN_EMAIL'] = 'admin@gamblecodez.com';
?>